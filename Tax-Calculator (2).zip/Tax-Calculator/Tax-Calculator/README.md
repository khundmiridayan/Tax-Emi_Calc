# Tax-Calculator
Android App to Calculate Income Tax and EMI
